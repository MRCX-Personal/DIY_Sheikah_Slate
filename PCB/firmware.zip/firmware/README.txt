工程来自https://github.com/solosky/nfc-emu
固件源代码、烧录教程请参考原作者Github页面
PCB、源程序作者solosky，本人参考学习并且对PCB做了些改动。
基于Apache License 2.0协议开源